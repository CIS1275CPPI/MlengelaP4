/*********************************************************************************
* Program:Separate files for function prototypes and implementations
* programmer: Duadi Mlengela (dmlengela@cnm.edu) 
* Date: 29 November 2021. 
* Purpose: Write a C++ Program with a function named Concatenate that will concatenate two strings. 
* It takes two strings as parameters and returns a string that is composed of the two strings. 
* Note that concatenating two strings does not put in an automatic space between the strings. 
* You may tell the user to add a space if they want one, or you may do it yourself in the program.
* Put the protoype of the function above main and the definition of the function after main. 
* In main, ask the user for two strings, call the function Concatenate, and display the result.
*********************************************************************************/



string Concatenate(string One, string Two);
#include <string>
#include <iostream>
using namespace std;

int main()
{
    cout << "\n This program will allow you to concatenate two strings.";

    string stringOne, stringTwo;  //declare  two string variables

    //ask for the strings to the concatenated
    cout << "\n Please enter the first string: ";
    getline(cin, stringOne);

    cout << "\n Please enter the second string: ";
    getline(cin, stringTwo);

    //show the results
    string result = Concatenate(stringOne, stringTwo);
    cout << "\n The result string is: " << result;

    return 0;
}

//definition of Concatenate
 string Concatenate(string one, string two)
{
    return one + " " + two;
}
