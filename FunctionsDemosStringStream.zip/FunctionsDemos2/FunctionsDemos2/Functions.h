// Functions.h
// Programmer: Rob Garner (rgarner7@cnm.edu)
// Date: 11 Oct 2021
// Purpose: Header file for FunctionsDemos2

#ifndef _FUNCTIONS_H
#define _FUNCTIONS_H

#include <iostream>
#include <iomanip>
#include <sstream>
#include <string>
#include <vector>

using namespace std;

void ParentFunction();
void ChildFunction();
float GetFloatFromUser();
float AddTotal(float total, float numToAdd);
bool DoAnother();
bool FirstCharIsY(string text);
string GetUserName();
string Results(string name, vector<float> numbers, float total);

#endif // !_FUNCTIONS_H
