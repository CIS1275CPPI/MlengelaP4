// Driver.cpp
// Programmer: Rob Garner (rgarner7@cnm.edu)
// Date: 11 Oct 2021
// Purpose:  Driver for Functions Demo2 Demonstrates some basic function principles.

#include "Functions.h"
using namespace std;

int main()
{
    //Get users name
    string userName = GetUserName();

    //Total some numbers
    float total{ 0.0f };
    vector<float> numbers;

    do
    {
        float floatFrmUsr = GetFloatFromUser();
        numbers.push_back(floatFrmUsr);
        total = AddTotal(total, floatFrmUsr);
        cout << "Current total: " << total << endl;
    } while (DoAnother());

    //Display a report
    string report = Results(userName,numbers,total);

    cout << report;

    return 0;
}