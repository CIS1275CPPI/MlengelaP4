// Functions.cpp
// Programmer: Rob Garner (rgarner7@cnm.edu)
// Date: 11 Oct 2021
// Purpose: Function definitions for FunctionsDemo2

#include "Functions.h"
using namespace std;

void ParentFunction()
{
	cout << "Hello from parent function!" << endl;
	ChildFunction();
	cout << "Goodbye from parent function!" << endl;
}

void ChildFunction()
{
	cout << "Hello from child function!" << endl;
	cout << "Goodbye from child function!" << endl;
}

float GetFloatFromUser()
{
	float value;
	cout << "Please enter a floating point number: ";
	cin >> value;
	cin.ignore();
	return value;
}

float AddTotal(float total, float numToAdd)
{
	return total + numToAdd;
}

bool DoAnother()
{
	string doAnother;
	cout << "Do another (y/n)? ";
	getline(cin, doAnother);	
	return FirstCharIsY(doAnother);
}

string GetUserName()
{
	string name;
	cout << "Please enter your name: ";
	getline(cin, name);
	return name;
}

bool FirstCharIsY(string text)
{
	char firstCharacter = text.at(0);
	char lowerFirstCharacter = tolower(firstCharacter);
	bool firstCharIsY = lowerFirstCharacter == 'y';
	return firstCharIsY;
}

string Results(string name, vector<float> numbers, float total)
{
	//Create a string stream object
	stringstream sstr;

	//Stream to the string stream object instead of cout
	sstr << setprecision(2);
	sstr <<fixed;
	sstr << "Here are your numbers " << name << endl;
	for (int i = 0; i < numbers.size(); ++i)
	{
		sstr << numbers.at(i) << endl;
	}
	sstr << "And the total is " << total << endl <<endl;

	//Convert string stream object to string
	string text = sstr.str();
	return text;
}

//Uses more memory: 
// 
//string ResultsConcat(string name, vector<float> numbers, float total)
//{
//	//Create a string stream object
//	string text;
//
//	//Stream to the string stream object instead of cout
//	text += "Here are your numbers " + name + "\n";
//	for (int i = 0; i < numbers.size(); ++i)
//	{
//		text += to_string(numbers.at(i)) + "\n";
//	}
//	text += "And the total is " + to_string(total) + "\n\n";
//
//	return text;
//}