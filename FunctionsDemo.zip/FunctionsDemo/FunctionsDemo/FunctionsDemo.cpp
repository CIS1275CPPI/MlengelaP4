// FunctionDemo.cpp 
// Programmer: Rob Garner (rgarner7@cnm.edu)
// Date: 29 Sep 2021
// Purpose: Demonstrate How to write functions

#include <iostream>
#include <string>

using namespace std;

//Function Prototypes
void DisplayHeader();
void SayGoodbyeToUser();
double GetLengthOfSideFromUser();
string GetNameOfUser();
double CalculateAreaOfTriangle(double sideA, double sideB);
void DisplayResultsToUser(double sideA, double sideB, double area, string name); 

int main()
{
    DisplayHeader();

    string name = GetNameOfUser();

    //Start do another loop
    string doAnother{ "" };
    do
    {
        double lengthSide1 = GetLengthOfSideFromUser();
        double lengthSide2 = GetLengthOfSideFromUser();
        double area = CalculateAreaOfTriangle(lengthSide1, lengthSide2);
        DisplayResultsToUser(lengthSide1, lengthSide2, area, name);

        cout << "Do another (y/n)? ";
        getline(cin, doAnother);

    } while (doAnother == "y");

    SayGoodbyeToUser();

    return 0;
}

//Function Definitions

//Display header that tells user what this program does.
void DisplayHeader()
{
    cout << "Welcome to super triangle area calculator 30000!" << endl;
    cout << "The best triable area claculator in the multivers." << endl << endl;
}

//Say goodbye to the user and thank them.
void SayGoodbyeToUser()
{
    cout << "Thank you for using my program." << endl;
}

//Gets the length of a side of a triangle
double GetLengthOfSideFromUser()
{
    double length{ 0.0 };
    cout << "Please enter length of side: ";
    cin >> length;
    cin.ignore();
    return length;
}

string GetNameOfUser()
{
    string name;
    cout << "Please enter your name: ";
    getline(cin, name);
    return name;
}

//Calculate area of a triangle
//Formula A=SideA*SideB/2
double CalculateAreaOfTriangle(double sideA, double sideB)
{
    double areaOfTriangle = sideA * sideB / 2;
    return areaOfTriangle;
}

//Display results
void DisplayResultsToUser(double sideA, double sideB, double area, string name)
{
    cout << "Well " << name << ", given one side of length " << sideA
        << " and another side of length " << sideB
        << " the area of the right triangle is " << area << "." << endl << endl;
}
